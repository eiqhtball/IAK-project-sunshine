package com.example.iqbal.sunshine


import android.support.constraint.ConstraintLayout
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.iqbal.sunshine.model.Weather

/**
 * Created by iqbal on 27/01/18.
 */
class WeatherAdapter(private val weatherList: List<Weather>) : RecyclerView.Adapter<WeatherAdapter.Holder>() {

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): Holder {
            val view: View? = LayoutInflater.from(parent?.context)
                    .inflate(R.layout.item_cuaca
                            , ConstraintLayout(parent?.context)
                            , false)
            return Holder(view)
    }

    override fun getItemCount(): Int = weatherList.size

    override fun onBindViewHolder(holder: Holder?, position: Int) {
        holder?.bind(position)
    }


    inner class Holder(itemView: View?) : RecyclerView.ViewHolder(itemView){
        fun bind(position: Int) {
        val weather = weatherList[position]
            TODO("nampilin data ke dalam ui list")
        }

    }

}