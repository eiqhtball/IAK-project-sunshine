package com.example.iqbal.sunshine

import com.example.iqbal.sunshine.model.ForecastResponse
import retrofit2.Call
import retrofit2.http.GET

/**
 * Created by iqbal on 27/01/18.
 */
interface Api {
    @GET("forecast?id=1621177&appid=b7ad75adf945f5e7f8e37793e9100ffd")
    fun getForecast(): Call<ForecastResponse>

}