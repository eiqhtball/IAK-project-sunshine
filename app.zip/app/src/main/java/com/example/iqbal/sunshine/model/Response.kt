package com.example.iqbal.sunshine.model

import com.google.gson.annotations.SerializedName

/**
 * Created by iqbal on 27/01/18.
 */

data class ForecastResponse(
        @field:SerializedName("cod")
        val cod: String? = "",

        @field:SerializedName("message")
        val message: String? = "",

        @field:SerializedName("city")
        val city: City? = City(),

        @field:SerializedName("list")
        val forecastList: List<Forecast>? = null

)
data class City(
        @field:SerializedName("id")
        val id: String? ="",

        @field:SerializedName("name")
        val name: String? = "",

        @field:SerializedName("country")
        val country: String? = ""
)

data class Forecast(
        @field:SerializedName("dt_txt")
        val dtTxt: String? = "",

        @field:SerializedName("")
        val weather: List<Weather>? = null
)

data class Weather(
        @field:SerializedName("id")
        val id: String? = "",

        @field:SerializedName("main")
        val main: String? = "",

        @field:SerializedName("description")
        val description: String? = "",

        @field:SerializedName("icon")
        val icon: String? = ""
)