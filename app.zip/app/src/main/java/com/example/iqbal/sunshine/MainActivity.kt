package com.example.iqbal.sunshine

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log.e
import android.util.Log.i
import com.example.iqbal.sunshine.model.ForecastResponse
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private val tag = this::class.java.simpleName
    //api.openweathermap.org/data/2.5/forecast?id=1621177&appid=b7ad75adf945f5e7f8e37793e9100ffd
    //b7ad75adf945f5e7f8e37793e9100ffd
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        getData()
    }

    private fun getData(){
        App.api.getForecast().enqueue(object : Callback<ForecastResponse> {
            override fun onResponse(call: Call<ForecastResponse>?, response: Response<ForecastResponse>?) {
                i(tag, "data : ${Gson().toJsonTree(response?.body())}")
            }

            override fun onFailure(call: Call<ForecastResponse>?, t: Throwable?) {

                e(tag, t?.message)
            }
        })
    }
}
